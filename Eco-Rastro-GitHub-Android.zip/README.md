# Eco-Rastro — aplicación Android

Aplicación Android inicial para el proyecto Eco-Rastro. Incluye:
- Registro diario de consumo de agua, energía y residuos.
- Puntos Eco, niveles e insignias.
- Guía básica de separación de residuos.
- Consejos para reducir la huella ecológica.
- Muro comunitario local.

## Cómo generar el APK directamente desde GitHub

1. Crea un repositorio nuevo en GitHub (por ejemplo, `eco-rastro`).
2. Descomprime este ZIP y sube **todo el contenido** del proyecto a la raíz del repositorio.
3. En GitHub entra a **Actions** y habilita los workflows si GitHub te lo solicita.
4. Abre el workflow **Construir APK Android** y pulsa **Run workflow**. También se ejecuta automáticamente al hacer push a `main` o `master`.
5. Cuando termine correctamente, abre la ejecución y descarga el artefacto **EcoRastro-debug-apk**. Dentro encontrarás `app-debug.apk`.
6. Pasa el APK a tu Android e instálalo. Si Android lo solicita, permite instalar aplicaciones desde esa fuente.

## Requisitos y notas

- El workflow compila con JDK 17, Gradle 8.9 y Android Gradle Plugin 8.7.3.
- El APK generado es de depuración (`debug`), suficiente para probar y compartir para pruebas.
- Los registros, puntos y publicaciones se guardan en el almacenamiento local del teléfono. No se sincronizan entre dispositivos.
- El ranking comunitario entre usuarios, inicio de sesión, nube y notificaciones requieren un backend; no se simulan como si ya estuvieran conectados.
- Para publicar en Google Play se recomienda preparar una versión `release` firmada con una clave privada que debes guardar como secreto de GitHub. No subas esa clave al repositorio.
